


 //导航的hover效果、二级菜单等功能，需要依赖element模块
layui.use('element', function(){
    var element = layui.element; //导航的hover效果、二级菜单等功能，需要依赖element模块
})
 //弹框模块 
layui.use('layer', function(){
    var layer = layui.layer;
})

//执行一个laydate实例 时间选择器
layui.use('laydate', function(){
    var laydate = layui.laydate;
     
    laydate.render({
        elem: '#startTime' //指定元素
    });
    laydate.render({
        elem: '#endTime' //指定元素
    });
    laydate.render({
        elem: '#startTime2' //指定元素
    });
    laydate.render({
        elem: '#endTime2' //指定元素
    });
    laydate.render({
        elem: '#startTime3' //指定元素
    });
    laydate.render({
        elem: '#endTime3' //指定元素
    });
   
  });
// 修改密码 表单模块
layui.use(['form'], function () {
    var form = layui.form,
      $ = layui.jquery,
      upload = layui.upload;
    //监听提交
    form.on('submit(formPass)', function (data) {
      if (data) {
       
      }
      var temp = data.field,
      old_pass = temp.old_pass,
      new_pass = temp.new_pass,
      new_pass2 = temp.new_pass2;
      console.log(old_pass)
      console.log(md5(old_pass))
      if(new_pass != new_pass2){
        layer.msg('新密码不一致！');
        return false;
      }
       
    //   $.ajax({
    //       type: "post",
    //       url: "url",
    //       data: {
    //         old_pass:old_pass,
    //         new_pass:new_pass
    //       },
    //       dataType: "json",
    //       success: function (res) {
    //         layer.msg(res.message);
    //         if(res.flag == 'success'){
    //             location.href = "<{:U('Admin/index')}>";
    //         }
    //       }
    //   });
     
      // layer.msg(JSON.stringify(data.field));
      return false;
    });

  });


$(function(){
    // 修改密码
    $('#updatePass').click(function(){
        layer.open({
            type: 1,
            title: ['修改密码', 'background-color: #dde5e7;'],
            area: '500px',
         
            anim: 1,
           
            content: $('#adminPopup'),
            end: function () {

                $('#adminPopup').hide();
            }

        });
    
    });


    //会员左侧导航栏

    $('.side-nav-item').click(function(){

        if(!$(this).hasClass("active")){
            $(this).addClass('active');
            $(this).siblings('dl').slideToggle(500);
        }else{
            $(this).removeClass('active');
            $(this).siblings('dl').slideToggle(500);
        }
    
    });
       //  //左侧菜单选中
    var urlstr = location.href;
    // console.log(urlstr)
  
    $('.side-nav-child-wrapper a').each(function () {
      
        if((urlstr).indexOf($(this).attr('href')) != -1 && $(this).attr('href') != "" ){
          
            $(this).parents('dl').siblings('.side-nav-item').addClass('active');
            $(this).parents('dl').slideToggle(500);
        }
    });
       //全选
    $("table thead th input:checkbox").on("click" , function(){
        $(this).closest("table").find("tr > td:first-child input:checkbox").prop("checked",$("table thead th input:checkbox").prop("checked"));
    });



   
	
})

// 城市三级联动
$.ajaxSettings.async = false;
function getProvinceData(pid,form){
    $.post("http://47.94.249.58/ddyk/index.php/Api/sign/province",{},function (res) {
  
        if(!res.flag){
          layer.msg(res.info)
        }else{
          var $html = "";
          if(res.data != null) {
            $.each(res.data, function (index, item) {
              $html += "<option value='" + item.id + "'>" + item.province + "</option>";
            });
            $("#province").append($html);
            //append后必须从新渲染
            if(form){
                form.render('select');
            }
            
          }
        }
      
      });
}
function getCityData(pid,form,cid){
    $.post("http://47.94.249.58/ddyk/index.php/Api/sign/city",{"pid":pid},function (res) {

          // console.log(res)
          if(!res.flag){
            layer.msg(res.info)
          }else{
            var $html = "";
            if(res.data != null) {
              $.each(res.data, function (index, item) {
                if(item.id == cid){
                    $html += "<option value='" + item.id + "' selected=''>" + item.city + "</option>";
                  }else{
                    $html += "<option value='" + item.id + "'>" + item.city + "</option>";
                  }
                 
              });
              $("#city").append($html);
              //append后必须从新渲染
              if(form){
                form.render('select');
                }
              
            }
          }
      
        });
}


function getAreaData(cid,form,aid){
    $.post("http://47.94.249.58/ddyk/index.php/Api/sign/country",{"cityId":cid},function (res) {
          if(!res.flag){
            layer.msg(res.info)
          }else{
            var $html = "";
            if(res.data != null) {
              $.each(res.data, function (index, item) {
                if(item.id == aid){
                    $html += "<option value='" + item.id + "'  selected=''>" + item.country + "</option>";
                  }else{
                    $html += "<option value='" + item.id + "'>" + item.country + "</option>";
                  }
              });
              $("#area").append($html);
              //append后必须从新渲染
              if(form){
                form.render('select');
              }
            }
          }
      
        });
      
}




String.prototype.queryURLParameter = function(){
    var obj = {},
    reg = /([^?=&#]+)=([^?=&#]+)/g;
    this.replace(reg,function(){
      var key = arguments[1],
      value = arguments[2];
      obj[key] = value;
    })
    return obj;
  }
// 热度显示封装
$.fn.extend({
    rating:function(num,leng){
      var itemLength = leng || 5;
      var rating = $(this);
    //  创建热度方块
      var str ='';
      for(var i=0;i<itemLength;i++){
        str += '<li class="rating-item"></li>';
      }
      rating.html( str );
    //  获取方块类数据
      items =  rating.find('.rating-item');

      if(num>=0&&num<500){
          hotNum = 1;
      }else   if(num>499&&num<1000){
        hotNum = 2;
      }else   if(num>999&&num<1500){
        hotNum = 3;
      }else   if(num>1499&&num<2000){
        hotNum = 4;
      }else if(num>=2000){
        hotNum = 5;
      }else{
          hotNum =1;
      }
    //  方块 给定 热度数值
      items.each(function(index){
          if(index<hotNum){
         
            $(this).addClass('active');
          }
    
      })
    }
});
